from rest_framework import serializers

# post employee personal data
class emp_regis_serializers(serializers.Serializer):
    employee_id = serializers.IntegerField()
    first_name = serializers.CharField(max_length=100)
    last_name = serializers.CharField(max_length=100)
    gender = serializers.CharField(max_length=100)
    email = serializers.EmailField(max_length=100)
    birth_date = serializers.CharField(max_length=100)
    hire_date = serializers.CharField(max_length=100)
    password = serializers.CharField(max_length=50)
    c_password = serializers.CharField(max_length=50)

class update_serializer(serializers.Serializer):
    employee_id = serializers.IntegerField()
    first_name = serializers.CharField(max_length=100)
    last_name = serializers.CharField(max_length=100)
    gender = serializers.CharField(max_length=100)
    email = serializers.EmailField(max_length=100)
    birth_date = serializers.CharField(max_length=100)
    hire_date = serializers.CharField(max_length=100)
    password = serializers.CharField(max_length=50)
    c_password = serializers.CharField(max_length=50)


# post employee emergency contact information
class emp_emergencycontactSerializers(serializers.Serializer):
    employee_id = serializers.IntegerField()
    Relation_Type = serializers.CharField(max_length=100)
    Relation_Name = serializers.CharField(max_length=100)
    Mobile = serializers.IntegerField()
    address = serializers.CharField(max_length=100)

class emp_emergencycontact1Serializers(serializers.Serializer):
    employee_id = serializers.IntegerField()
    Relation_Type = serializers.CharField(max_length=100)
    Relation_Name = serializers.CharField(max_length=100)
    Mobile = serializers.IntegerField()
    address = serializers.CharField(max_length=100)


# get all employee personal data
class getallemployee_serializers(serializers.Serializer):
    employee_id = serializers.IntegerField()
    first_name = serializers.CharField(max_length=100)
    last_name = serializers.CharField(max_length=100)
    gender = serializers.CharField(max_length=100)
    email = serializers.EmailField(max_length=100)
    birth_date = serializers.CharField(max_length=100)
    hire_date = serializers.CharField(max_length=100)
    password = serializers.CharField(max_length=50)
    c_password = serializers.CharField(max_length=50)

# get all employee personal data using employee id(primary key)

class emp_emergencySerializers(serializers.Serializer):
    employee_id = serializers.IntegerField()
    Relation_Type = serializers.CharField(max_length=100)
    Relation_Name = serializers.CharField(max_length=100)
    Mobile = serializers.IntegerField()
    address = serializers.CharField(max_length=100)


# get any perticular employee personal data using employee id(primary key) in url
class getemployeeDataSerializers(serializers.Serializer):
    employee_id = serializers.IntegerField()


# get any perticular employee personal data using employee id(primary key) in url

class getemp_emergency_contactSerializers(serializers.Serializer):
    employee_id = serializers.IntegerField()


class employee_education_serializers(serializers.Serializer):
    employee_id = serializers.IntegerField()
    Employee_name= serializers.CharField(max_length=100)
    Course_name = serializers.CharField(max_length=100)
    Board = serializers.CharField(max_length=100)
    Institute = serializers.CharField(max_length=100)
    Location = serializers.CharField(max_length=100)
    Percentage = serializers.IntegerField()

class getalleducation_serializers(serializers.Serializer):
    employee_id = serializers.IntegerField()
    # Employee_name = serializers.CharField(max_length=100)
    # Course_name = serializers.CharField(max_length=100)
    # Board = serializers.CharField(max_length=100)
    # Institute = serializers.CharField(max_length=100)
    # Location = serializers.CharField(max_length=100)
    # Percentage = serializers.IntegerField()
