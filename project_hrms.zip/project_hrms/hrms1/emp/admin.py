from django.contrib import admin

# Register your models here.
from django.contrib import admin
from . models import *

admin.site.register(emp_personal)
admin.site.register(emergency_contact)
admin.site.register(Employee_education)