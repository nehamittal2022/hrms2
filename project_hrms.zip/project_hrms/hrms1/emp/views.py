from rest_framework.views import APIView
from rest_framework.response import Response
from django.http import JsonResponse
from rest_framework import status
from . models import *
from . serializers import *

# creating employee personal details

class EmployeeAPI(APIView):
    def post(self, request):
        try:
            input_data = emp_regis_serializers(data=request.data)
            if input_data.is_valid():
                employee_id = input_data.data['employee_id']
                first_name = input_data.data['first_name']
                last_name = input_data.data['last_name']
                email = input_data.data['email']
                gender = input_data.data['gender']
                birth_date = input_data.data['birth_date']
                hire_date = input_data.data['hire_date']
                password = input_data.data['password']
                c_password = input_data.data['c_password']

                emp_personal.objects.create(
                    employee_id=employee_id,
                    first_name=first_name,
                    last_name=last_name,
                    email=email,
                    gender=gender,
                    birth_date=birth_date,
                    hire_date=hire_date,
                    password=password,
                    c_password=c_password
                    )

                print(employee_id)
                result = {"message":"user registered successfully"}

                return JsonResponse(result,status=status.HTTP_200_OK)
            return JsonResponse(input_data.errors,status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
                error = {'error': str(e)}
                return JsonResponse(error, status=status.HTTP_400_BAD_REQUEST)


# creating employee emergency contact details

class emergency_contactAPI(APIView):
    def post(self, request):
        try:
            input_data = emp_emergencycontactSerializers(data=request.data)
            if input_data.is_valid():
                employee_id = input_data.data['employee_id']
                Relation_Type = input_data.data['Relation_Type']
                Relation_Name = input_data.data['Relation_Name']
                Mobile = input_data.data['Mobile']
                address = input_data.data['address']

                emergency_contact.objects.create(
                    employee_id_id=employee_id,
                    Relation_Type=Relation_Type,
                    Relation_Name=Relation_Name,
                    Mobile=Mobile,
                    address=address,
                    )

                # print(employee_id_id)
                result = {"message":"user registered successfully"}

                return JsonResponse(result,status=status.HTTP_200_OK)
            return JsonResponse(input_data.errors,status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
                error = {'error': str(e)}
                return JsonResponse(error, status=status.HTTP_400_BAD_REQUEST)

# creating educating details

class EmployeeEducationAPI(APIView):
    def post(self, request):
        try:
            input_data = employee_education_serializers(data=request.data)
            if input_data.is_valid():
                employee_id = input_data.data['employee_id']
                Employee_name = input_data.data['Employee_name']
                Course_name = input_data.data['Course_name']
                Board = input_data.data['Board']
                Institute = input_data.data['Institute']
                Location = input_data.data['Location']
                Percentage = input_data.data['Percentage']


                Employee_education.objects.create(
                    employee_id_id=employee_id,
                    Employee_name=Employee_name,
                    Course_name=Course_name,
                    Board=Board,
                    Institute=Institute,
                    Location=Location,
                    Percentage=Percentage
                    )

                # print(employee_id_id)
                result = {"message":"user registered successfully"}

                return JsonResponse(result,status=status.HTTP_200_OK)
            return JsonResponse(input_data.errors,status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
                error = {'error': str(e)}
                return JsonResponse(error, status=status.HTTP_400_BAD_REQUEST)


# get all employee data

class getallemployeeDataAPI(APIView):
    def get(self, request):
        data = emp_personal.objects.all()
        print("data is", data)
        input_data = getallemployee_serializers(data, many=True)
        print(input_data.data)
        result={"message":"All DAta","data":input_data.data}
        return JsonResponse(result, status=status.HTTP_200_OK)

# get all employee data using filter(employee_id)

class getallemployeeAPI(APIView):
    def get(self,request):
        input_data = getemployeeDataSerializers(data=request.data)
        if input_data.is_valid():
            employee_id=input_data.data['employee_id']
            print(employee_id)
            data=emp_personal.objects.filter(employee_id_id=employee_id).values()[0]
            print(data)
            result={"message":"user details are","data":data}
            return JsonResponse(result,status=status.HTTP_200_OK,safe=True)
        return JsonResponse(input_data.errors,status=status.HTTP_400_BAD_REQUEST)


# get all emergency contact data

class getemergencyDataAPI(APIView):
    def get(self, request):
        try:
            data = emergency_contact.objects.all()
            print("data is", data)
            input_data = emp_emergencySerializers(data, many=True)
            print(input_data.data)
            result = {"message":"All DAta","data": input_data.data}
            return JsonResponse(result, status=status.HTTP_200_OK)
        except Exception as e:
            error = {"errors":str(e)}
            return JsonResponse(error,status=status.HTTP_400_BAD_REQUEST)


# get all emergency data using filter(employee_id)

class getemp_emergencyAPI(APIView):
    def get(self,request):
        input_data = getemp_emergency_contactSerializers(data=request.data)
        if input_data.is_valid():
            employee_id = input_data.data['employee_id']
            print(employee_id)
            data = emergency_contact.objects.filter(employee_id_id=employee_id).values()[0]
            print(data)
            result={"message":"user details are","data":data}
            return JsonResponse(result, status=status.HTTP_200_OK, safe=True)
        return JsonResponse(input_data.errors, status=status.HTTP_400_BAD_REQUEST)


# get all education data using filter(employee_id)

class getallemployee_educationDataAPI(APIView):
    def get(self,request):
        input_data = getalleducation_serializers(data=request.data)
        if input_data.is_valid():
            employee_id=input_data.data['employee_id']
            print(employee_id)
            data=Employee_education.objects.filter(employee_id_id=employee_id).values()[0]
            print(data)
            result={"message":"user details are","data":data}
            return JsonResponse(result,status=status.HTTP_200_OK,safe=True)
        return JsonResponse(input_data.errors,status=status.HTTP_400_BAD_REQUEST)


# update emergency contact detail
class emergency_updatecontactAPI(APIView):
    def put(self, request, employee_id):
        try:
            input_data = emp_emergencycontact1Serializers(data=request.data)
            if input_data.is_valid():
                employee_id = input_data.data['employee_id']
                Relation_Type = input_data.data['Relation_Type']
                Relation_Name = input_data.data['Relation_Name']
                Mobile = input_data.data['Mobile']
                address = input_data.data['address']

                emergency_contact.objects.filter(employee_id_id=employee_id).update(
                    Relation_Type=Relation_Type,
                    Relation_Name=Relation_Name,
                    Mobile=Mobile,
                    address=address,
                    )
                result = {"message":"user registered successfully"}

                return JsonResponse(result,status=status.HTTP_200_OK)
            return JsonResponse(input_data.errors,status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
                error = {'error': str(e)}
                return JsonResponse(error, status=status.HTTP_400_BAD_REQUEST)


# update employee personal data

class updateemployeedataAPI(APIView):
    def put(self, request, employee_id):
        try:
            input_data = update_serializer(data=request.data)
            if input_data.is_valid():
                employee_id = input_data.data['employee_id']
                first_name = input_data.data['first_name']
                last_name = input_data.data['last_name']
                email = input_data.data['email']
                gender = input_data.data['gender']
                birth_date = input_data.data['birth_date']
                hire_date = input_data.data['hire_date']
                password = input_data.data['password']
                c_password = input_data.data['c_password']

                emp_personal.objects.filter(employee_id=employee_id).update(
                    first_name=first_name,
                    last_name=last_name,
                    email=email,
                    gender=gender,
                    birth_date=birth_date,
                    hire_date=hire_date,
                    password=password,
                    c_password=c_password
                )
                print("user registered successfully")
                return JsonResponse(input_data.data)
            return JsonResponse(input_data.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            error = {"error": str(e)}
            return JsonResponse(error, status=status.HTTP_404_NOT_FOUND)


# delete employee_personal data

class delete_employeedataAPI(APIView):
    def delete(self, request, ):
        try:
            input_data = getemployeeDataSerializers(data=request.data)
            if input_data.is_valid():
                employee_id = input_data.data['employee_id']
                alldata = emp_personal.objects.get(employee_id=employee_id).delete()
                result = {"massage": alldata}
                return JsonResponse(result, status=status.HTTP_200_OK)
            return JsonResponse(input_data.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            errors = {"error": str(e)}
            return JsonResponse(errors, status=status.HTTP_400_BAD_REQUEST)


