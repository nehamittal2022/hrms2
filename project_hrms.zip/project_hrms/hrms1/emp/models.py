from django.db import models

class emp_personal(models.Model):
    employee_id = models.IntegerField(primary_key=True)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    gender = models.CharField(max_length=100)
    email = models.EmailField(max_length=100)
    birth_date = models.CharField(max_length=100)
    hire_date = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    c_password = models.CharField(max_length=100)


    def __str__(self):
        return(self.first_name)

class emergency_contact(models.Model):
    employee_id = models.ForeignKey(emp_personal,on_delete=models.CASCADE)
    Relation_Type = models.CharField(max_length=100)
    Relation_Name = models.CharField(max_length=100)
    Mobile = models.IntegerField()
    address = models.CharField(max_length=100)


    def __str__(self):
        return(self.Relation_Name)


class Employee_education(models.Model):
    employee_id = models.ForeignKey(emp_personal,on_delete=models.CASCADE)
    Employee_name = models.CharField(max_length=100)
    Course_name = models.CharField(max_length=100)
    Board = models.CharField(max_length=100)
    Institute = models.CharField(max_length=100)
    Location = models.CharField(max_length=100)
    Percentage = models.IntegerField()

    def __str__(self):
        return(self.Employee_name)






















#A      a
# class emp_contact(models.Model):
#     employee_id= models.IntegerField(primary_key=True)
#     mobile = models.IntegerField(max_length=100)
#     telephone = models.IntegerField(max_length=100)
#
#
# class emp_experiance(models.Model):
#     employee_id= models.IntegerField(primary_key=True)
#     exp1 = models.CharField(max_length=100)
#     exp2 = models.CharField(max_length=100)
#
# class emp_salary(models.Model):
#     employee_id = models.IntegerField(primary_key=True)
#     current_salary = models.CharField(max_length=100)
#     initial_salary = models.CharField(max_length=100)
#     last_appraisel = models.IntegerField()
#
#
# class emp_leave(models.Model):
#     employee_id = models.IntegerField(primary_key=True)
#     monthly_leave = models.CharField(max_length=100)
#     yearly_leave = models.CharField(max_length=100)
#
# class department(models.Model):
#     dept_id = models.IntegerField(primary_key=True)
#     dept_name = models.CharField(max_length=100)
#     member_count = models.CharField(max_length=100)
#
# class emp_department(models.Model):
#     employee_id = models.IntegerField(primary_key=True)
#     dept_id = models.IntegerField(primary_key=True)
#     from_date = models.CharField(max_length=100)
#     to_date = models.CharField(max_length=100)
#
# class emp_current_project(models.Model):
#     employee_id = models.IntegerField(primary_key=True)
#     project_id = models.IntegerField(primary_key=True)
#     from_date = models.CharField(max_length=100)
#     to_date = models.CharField(max_length=100)
#
